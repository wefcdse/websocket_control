function Locate(ws)
    local x, y, z = gps.locate()
    if x == nil or y == nil or z == nil then
        ws.send("failed")
        return
    end
    -- print(string.format("%d %d %d", x, y, z))
    ws.send(string.format("%d %d %d", x, y, z))

end

return { Locate = Locate }