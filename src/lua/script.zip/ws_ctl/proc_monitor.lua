function WriteAtWithBGColor(side, x, y, text, bg_color, txt_color)
    local p = peripheral.wrap(side);
    if p == nil then
        print(side)
        return
    end

    local x_max, y_max = p.getSize()


    if x_max < x or y_max < y then
        print(x, x_max, y, y_max)
        return
    end

    -- print("hered")

    p.setCursorPos(x, y)

    p.setBackgroundColour(bg_color)
    p.setTextColour(txt_color)

    p.write(text)

end

function WriteAtWithBGColorWithP(p, x_max, y_max, x, y, text, bg_color, txt_color)

    if x_max < x or y_max < y then
        print(x, x_max, y, y_max)
        return
    end

    -- print("hered")

    p.setCursorPos(x, y)

    p.setBackgroundColour(bg_color)
    p.setTextColour(txt_color)

    p.write(text)

end


function GetSize(ws, side)
    local p = peripheral.wrap(side);
    if p == nil then
        ws.send("none")
        return
    end
    if not (peripheral.getType(p) == "monitor") then
        ws.send("none")
    end
    local x, y = p.getSize()
    ws.send(string.format("%d %d", x, y))
end

return { 
    WriteAtWithBGColor = WriteAtWithBGColor, 
    GetSize = GetSize,
    WriteAtWithBGColorWithP = WriteAtWithBGColorWithP
}