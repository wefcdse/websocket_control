function GetRedstone(ws, side)
    local level = 0
    level = redstone.getAnalogInput(side)
    ws.send(level)
end

function SetRedstone(side, level)
    redstone.setAnalogOutput(side,tonumber(level))
end

return { GetRedstone = GetRedstone, SetRedstone = SetRedstone }