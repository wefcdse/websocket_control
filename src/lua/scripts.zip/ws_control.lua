Args = {...}
Id = Args[1]
Port = Args[2]

if Id == nil then
    Id = ""
end

if Port == nil then
    Port = "14111"
end

while true do
    local ok = shell.run("ws_ctl/run_", Id, Port)
    sleep(0.05)
    if not ok then
        print("error")
    else
        print("ok")
    end
end
