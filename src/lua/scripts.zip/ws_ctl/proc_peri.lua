function ProcPeri(ws, side)
    local p = peripheral.wrap(side);
    if p == nil then
        ws.send("none");
        return
    end
    local p1 = {peripheral.getType(p)}
    ws.send(p1[#p1])
end

return { ProcPeri = ProcPeri }