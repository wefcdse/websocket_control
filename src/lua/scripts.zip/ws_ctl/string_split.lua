
function split(input, delimiter)
    if type(delimiter) ~= "string" or #delimiter <= 0 then
        return
    end
    local start = 1
    local arr = {}
    while true do
        local pos = string.find(input, delimiter, start, true)
        if not pos then
            break
        end
        table.insert (arr, string.sub (input, start, pos - 1))
        start = pos + string.len (delimiter)
    end
    table.insert (arr, string.sub (input, start))
    return arr
end
return {split = split}