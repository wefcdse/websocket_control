-- local ws = assert(http.websocket("wss://example.tweaked.cc/echo"))
local ws = assert(http.websocket("ws://127.0.0.1:13000/ws"))

-- print(os.clock())
-- ws.send("Hello!") -- Send a message
-- print(ws.receive()) -- And receive the reply
-- print(os.clock())

-- for i = 1, 10, 1 do
--     ws.send("a")
-- end
local helm = peripheral.find("ship_helm")

while true do
    ws.send("t")
    local msg , cond =   ws.receive()
    local sig_t = tonumber(msg)

    -- print(msg)
    -- sleep(0.2)
    local rs =math.max(math.min(sig_t * 16, 15), 0)
    -- peripheral.call("top","setTargetSpeed",rs)
    

    redstone.setAnalogOutput("top",rs);
    redstone.setAnalogOutput("front",rs);
    redstone.setAnalogOutput("back",rs);
    redstone.setAnalogOutput("left",rs);
    redstone.setAnalogOutput("right",rs);

    
end

ws.close()
